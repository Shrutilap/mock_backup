/*Implement all the functions of a dictionary (ADT) using open hashing technique: sep-
arate chaining using linked list Data: Set of (key, value) pairs, Keys are mapped to
values, Keys must be comparable, and Keys must be unique. Standard Operations: In-
sert(key, value), Find(key), Delete(key)*/
#include<iostream>
using namespace std;
class Node{
    public:
    string str;
    Node *next;
    Node(){
        str = "";
        next = nullptr;
       
    }
    Node(string str){
        this->str = str;
        next = nullptr;
    }
};
void insert(Node *arr[], int n){
    string str1;
    for(int i = 0; i<n; i++){
        cout<<"Enter string to be entered in dictionary : "<<endl;
        cin>>str1;
        int sum = 0;
        for(int i = 0; i<str1.size(); i++){
            sum += int(str1[i]);
        }
        int hash = sum%n;
        if(arr[hash] == nullptr){
            arr[hash]= new Node(str1);
        }
        else{
            Node *temp = arr[hash];
            while(temp->next != nullptr){
                temp = temp->next;
            }
            temp->next = new Node(str1);
        }
    }
}
void display(Node *arr[], int n){
    for(int i = 0; i<n; i++){
        if(arr[i] != nullptr){
            Node *temp = arr[i];
            while(temp != nullptr){
                    cout<<temp->str<<" ";
                    temp = temp->next;
                }
                cout<<endl;
        }
    }
}

void find(Node *arr[], int n, string str2){
    int sum = 0;
    int cnt = 0;
    for(int i = 0; i<str2.size(); i++){
        sum += int(str2[i]);
    }
    int hash = sum%n;
    if(arr[hash] != nullptr){
        bool flag = false;
        if(arr[hash]->str == str2){
            cnt++;
            cout<<str2<<" found at "<<hash<<" at place "<<cnt<<endl;
            flag = true;
        }
        else{
            cnt = 1;
            Node *temp = arr[hash];
            while(temp->str != str2){
                temp = temp->next;
                cnt++;
            }
            cout<<str2<<" found at "<<hash<<" at place "<<cnt<<endl;
            flag = true;
        }
        if(flag == false){
            cout<<str2<<" not in dictionary"<<endl;
        }
    }
}
void delete_word(Node *arr[], string toDel, int n){
    int sum = 0;
    int cnt = 0;
    for(int i = 0; i<toDel.size(); i++){
        sum += int(toDel[i]);
    }
    int hash = sum%n;
    if(arr[hash] != nullptr){
        
        if(arr[hash]->str == toDel){
            Node *ToDel = arr[hash];
            arr[hash] = arr[hash]->next;
            delete ToDel;
        }
        else{
            
            Node *temp = arr[hash];
            Node *prev = nullptr;
            while(temp->str != toDel){
                prev = temp;
                temp = temp->next;
            }
            Node *ToDel = temp;
            prev->next = ToDel->next;
            delete ToDel;
            
        }
    }


}
void initialise(Node *arr[], int n){
    for(int i = 0; i<n; i++){
        arr[i] = nullptr;
    }
}
int main(){
    int n = 0;
    cout<<"Enter number of elements : "<<endl;
    cin>>n;
    Node *arr[n];
    int choice;
    char ch;
    string to_find;
    string to_delete;
    initialise(arr, n);
    
    
    do{
        cout<<"Enter operation to be performend : "<<endl;
        cout<<"1) Insert"<<endl;
        cout<<"2) Find : "<<endl;
        cout<<"3) Delete : "<<endl;
        cin>>choice;
        switch(choice){
            case 1: insert(arr, n);
                    display(arr,n);
                    break;
            case 2: cout<<"Enter word to find : "<<endl;
                    cin>>to_find;
                    find(arr, n, to_find);
                    break;
            case 3:  cout<<"Enter word to delete : "<<endl;
                    cin>>to_delete;
                    delete_word(arr, to_delete, n);
                    display(arr,n);
                    break;
        }
        cout<<"Do you want to continue : "<<endl;
        cin>>ch;
        

    }while(ch == 'y');

    
    
    
    
    
    
    
    return 0;
}
/*Beginning with an empty binary tree, construct binary tree by inserting the values in
the order given. After constructing a binary tree perform following operations on it-
•Perform inorder, preorder and post order traversal
•Change a tree so that the roles of the left and right pointers are swapped at every
node
•Find the height of tree
•Copy this tree to another [operator=]
•Count number of leaves, number of internal nodes.
•Erase all nodes in a binary tree. (Implement both recursive and non-recursive meth-
ods)*/
#include <iostream>
#include<stack>
using namespace std;
int cnt = 0;
int cntInt = 0;
class Node{
    public:
    Node *left;
    Node *right;
    int data;
    public:
    Node(int val){
        data = val;
        left = nullptr;
        right = nullptr;
    }
};

class tree{
    public:
    Node *root;
    public:
    tree(){
        root = nullptr;
    }

    Node *eraseNodes(Node *root){
    if(root == nullptr){
        return nullptr;
    }
    
    eraseNodes(root->left);
    eraseNodes(root->right);
    delete root;
    return nullptr;
    }

    Node *copyTree(Node *root){
    if(root == nullptr){
        return nullptr;
    }
    Node *newNode = new Node(root->data);
    newNode->left = copyTree(root->left);
    newNode->right = copyTree(root->right);
    return newNode;
}

    tree& operator=(const tree& other){
        if(this == &other){
            return *this;
        }
        if (this->root) {
        root = eraseNodes(root); 
        }
        this->root = copyTree(other.root);
        return *this;
    }
};
Node *create(){
    int input;
    cout<<"Enter data (-1 for no node) : "<<endl;
    cin>>input;
    Node *newNode = new Node(input);
    if(input == -1){
        return nullptr;
    }
    cout<<"Enter data for left child of "<<input<<endl;
    newNode->left = create();
    cout<<"Enter data for right child of "<<input<<endl;
    newNode->right = create();
    return newNode; 
}

void preorder(Node *root){
    if(root == nullptr){
        return;
    }
    cout<<root->data<<" ";
    preorder(root->left);
    preorder(root->right);
}
void preorder_iter(Node *root){
    stack<Node *> s;
    if(root == nullptr){
        return;
    }
    s.push(root);
    while(!s.empty()){
        Node *t = s.top();
        s.pop();
        cout<<t->data<<" ";
        if(t->right){
            s.push(t->right);
        }
        if(t->left){
            s.push(t->left);
        }
    }
}
void postorder(Node *root){
    if(root == nullptr){
        return;
    }
    postorder(root->left);
    postorder(root->right);
    cout<<root->data<<" ";
}
void postorder_iter(Node *root){
    stack<Node *> s1;
    stack<Node *> s2;
    if(root == nullptr){
        return;
    }
    s1.push(root);
    while(!s1.empty()){
        Node *t = s1.top();
        s1.pop();
        s2.push(t);
        if(t->left){
            s1.push(t->left);
        }
        if(t->right){
            s1.push(t->right);
        }
        
        
    }
    while(!s2.empty()){
            Node *t = s2.top();
            cout<<t->data<<" ";
            s2.pop();
    }
}
void inorder(Node *root){
    if(root == nullptr){
        return;
    }
    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}
void inorder_iter(Node *root){
    stack<Node *> s;
    while(root != nullptr || !s.empty()){
        while(root != nullptr){
            s.push(root);
            root = root->left;
        }
        root = s.top();
        s.pop();
        cout<<root->data<<" ";
        root = root->right;
    }
}
int height(Node *root){
    if(root == nullptr){
        return 0;
    }
    int l =  1 + height(root->left);
    int r = 1 + height(root->right);
    return max(l,r);
    
}

int leaves(Node *root){
    int count = 0;
    
    if(root == nullptr){
        return 0;
    }
    if(root->left == nullptr && root->right == nullptr){
        return 1;
    }
    return leaves(root->left) + leaves(root->right);
    
}

int countInternalNodes(Node *root){
    if(root == nullptr){
        return 0;
    }
    if(root->left == nullptr || root->right == nullptr){
        return 0;

    }
    return 1 + countInternalNodes(root->left) + countInternalNodes(root->right);
}
void swapNodes(Node *root){
    if(root == nullptr){
        return;
    }
    Node *temp = root->left;
    root->left = root->right;
    root->right = temp;
    swapNodes(root->left);
    swapNodes(root->right);
}


int main()
{
    
    tree *T = new tree();
    T->root = create();
    int choice;
    do{
        cout<<endl;
        cout<<"Enter choice : "<<endl;
    cout<<"1) Perform inorder / preorder and post order traversal\n";
    cout<<"2) Change a tree so that the roles of the left and right pointers are swapped at every node\n";
    cout<<"3) Find the height of tree\n";
    cout<<"4) Copy this tree to another [operator=]\n";
    cout<<"5) Count number of leaves, number of internal nodes.\n";
    cout<<"6) Erase all nodes in a binary tree.\n";
    cin>>choice;
    switch(choice){
        case 1: cout<<"Inorder : ";
                inorder(T->root);
                cout<<endl;
                inorder_iter(T->root);
                cout<<endl;
                cout<<"Preorder : ";
                preorder(T->root);
                cout<<endl;
                preorder_iter(T->root);
                cout<<endl;
                cout<<"Postorder : ";
                postorder(T->root);
                cout<<endl;
                postorder_iter(T->root);
                cout<<endl;
                break;
        case 2 : swapNodes(T->root);
                inorder(T->root);
                break;
        case 3: cout<<height(T->root)<<endl;
                break;
        case 4: {tree T1;
                T1 = *T; 
                inorder(T1.root);
                break;
            }
        case 5 :cout<<"Internal nodes : "<<countInternalNodes(T->root)<<endl;
                cout<<"Leaves : "<<leaves(T->root)<<endl;
                break;
        case 6 : T->root = T->eraseNodes(T->root);
                break;
    }

    }while(choice != 7);
    
    return 0;
}
/*Consider telephone book database of N clients. Make use of a hash table implementa-
tion to quickly look up client‘s telephone number. Make use of two collision handling
techniques and compare them using number of comparisons required to find a set of
telephone numbers (Note: Use linear probing with replacement and without replace-
ment) */
#include<iostream>
#include<vector>
using namespace std;
class Probing{
    public: 
    int n;
    long long int arr[5];
    public:
    Probing(int size){
        n = size;
        // arr = new long long int[n]; 
        for(int i = 0; i<n; i++){
            arr[i] = -1;

        }
    }

    void hashworepl(){
        long long int tele;
        long long int store;
        for(int i = 0; i<n; i++){
            cout<<"enter tele no : "<<endl;
            cin>>tele;
            store = tele;
            int sum = 0;
            while(tele>0){
                int digit = tele%10;
                sum += digit;
                tele = tele/10;
            }
            int hash = sum%n;
            if(arr[hash] == -1){
                arr[hash] = store;
                cout<<sum%n<<endl;
            }
            else{
               
                int j = (hash+1)%n;
                 cout<<j<<endl;
                while(arr[j] != -1){
                    j = (j+1)%n;
                }
                arr[j] = store;
                
            }
            
        }
    }
    int hashFunc(long long int tele){
            int sum = 0;
            while(tele>0){
                int digit = tele%10;
                sum += digit;
                tele = tele/10;
            }
            int hash = sum%n;
            return hash;
    }
    void hashwrepl(){
        for(int i = 0; i<n; i++){
            long long int tele;
            long long int store;
            
            cout<<"Enter telephone number : "<<endl;
            cin>>tele;
            store = tele;

            int hash = hashFunc(tele);
            if(arr[hash] == -1){
                arr[hash] = store;
                cout<<hash<<endl;
            }
            else{
                int prevHash = hashFunc(arr[hash]);
                if(prevHash != hash){
                    int temp = arr[hash];
                    arr[hash] = store;
                    int j = (hash+1)%n;
                    cout<<j<<endl;
                    while(arr[j] != -1){
                        j = (j+1)%n;
                    }
                    arr[j] = temp;
                }
                else{
                    int j = (hash+1)%n;
                    cout<<j<<endl;
                    while(arr[j] != -1){
                        j = (j+1)%n;
                    }
                    arr[j] = store;
                }
            }
        }

    }
    
    void display(){
        for(int i = 0; i<n; i++){
            cout<<arr[i]<<" ";
        }
    }
    int search(){
        int search;
        int cnt = 0;
        cout<<"Enter element to be searched for : "<<endl;
        cin>>search;
        
        int hash = hashFunc(search);
        int i = hash;
        if(arr[hash] == search){
            cnt++; 
        }
        else{
            do{
                if(arr[i] == search){
                    cnt++;
                    break;
                }
                i = (i+1)%n;
            
            }while(i != hash);
            
            
        }
        return cnt;
    }
};
int main(){
    Probing p(5);
    Probing p1(5);
    p.display();
    p1.display();
    int choice;
    char ch;
    
    do{
        cout<<"ENter choice : "<<endl;
        cout<<"1) Probing without replacement : "<<endl;
        cout<<"2) Probing with replacement : "<<endl;
        cin>>choice;
        switch(choice){
            case 1 : p.hashworepl();
                    p.display();
                    cout<<endl;
                    cout<<p.search();
                    cout<<endl;
                    break;
            case 2 :  p1.hashwrepl();
                      p1.display();
                      cout<<endl;
                      cout<<p1.search();
                      cout<<endl;
                      
                      break;
        }
        
        cout<<"Do you want to continue?"<<endl;
        cin>>ch;

    }while(ch == 'y');
    
    
    return 0;
}
/*Construct the binary search tree by inserting the values in given order. After construct-
ing binary search tree perform following operations…... 1) Insert a new node 2) Find
numbers of node in longest path 3) Minimum and maximum data value found in tree
4) Change a tree so that the roles of the left and right pointers are swapped at every
node 5) Search an element*/
#include<iostream>
using namespace std;
class Node{
    public:
    Node *left;
    Node *right;
    int data;
    public:
    Node(int val){
        data = val;
        left = nullptr;
        right = nullptr;
    }
};
class BST{
    public:
    Node *root;
    
    BST(){
        root = nullptr;
    }
    void inorder(Node *root){
    if(root == nullptr){
        return;
    }
    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}
Node *insertNode(Node *root, int input){    
    Node *newNode = new Node(input);

    if(root == nullptr){
        return newNode;
    }
    if(input == -1){
        return nullptr;
    }
  
    if(input < root->data){
        root->left = insertNode(root->left, input);

    }
    else if(input > root->data){
        root->right = insertNode(root->right, input);
    }
    
    return root; 
}
int nodesHeight(Node *root){
    if(root == nullptr){
        return 0;
    }
    int l =  1 + nodesHeight(root->left);
    int r = 1 + nodesHeight(root->right);
    return max(l,r);                                       
}

int findMin(Node *root){
    while(root->left != nullptr){
        root = root->left;
    }
    return root->data;
}

int findMax(Node *root){
    while(root->right != nullptr){
        root = root->right;
    }
    return root->data;
}

void invertTree(Node *root){
    if(root == nullptr){
        return;
    }
    
    invertTree(root->left);
    invertTree(root->right);

    Node *temp;
    temp = root->left;
    root->left = root->right;
    root->right = temp;
}
void searchEle(int val, Node *root){
    if(root == nullptr){
        cout<<"Element not found"<<endl;
        return;
    }
    if(root->data == val){
        cout << "Element found" << endl;
    }
    else if(val < root->data){
        searchEle(val, root->left);
    }
    else{
        searchEle(val, root->right);
    }
    
}
};



int main(){
    BST *t = new BST();
    int input;
    while(true){
        cout<<"Enter data : "<<endl;
        cin>>input;
        if(input == -1){
            break;
        }
      
        t->root = t->insertNode(t->root, input);
    }
    t->inorder(t->root);
    char ch;
    do{
        int choice;
        
    cout<<"Enter choice : "<<endl;
    cout<<"1) Find numbers of node in longest path"<<endl;
    cout<<"2) Minimum data value found in tree"<<endl;
    cout<<"3) Maximum data value found in tree"<<endl;
    cout<<"4) Change a tree so that the roles of the left and right pointers are swapped at every node"<<endl;
    cout<<"5) Search for a value in the tree"<<endl;
    cin>>choice;
        switch(choice){
            case 1: cout<<t->nodesHeight(t->root)<<" is the number of nodes in the longest path of the tree"<<endl;
                    break;
            case 2: cout<<t->findMin(t->root)<<" is the minimum value found in the tree"<<endl;
                    break;
            case 3: cout<<t->findMax(t->root)<<" is the maximum value found in the tree"<<endl;
                    break;
            case 4: cout<<"Before inverting : "<<endl;
                    t->inorder(t->root);
                    t->invertTree(t->root);
                    cout<<"After inverting : "<<endl;
                    t->inorder(t->root);
                    break;  
            case 5: int val;
                    cout<<"Enter a value to be searched for : "<<endl;
                    cin>>val;
                    t->searchEle(val, t->root);
                    break;
            default: cout<<"Invalid choice"<<endl;
        }
        cout<<"Do you want to continue : "<<endl;
        cin>>ch;

    }while(ch == 'y');
        
    
    return 0;
}
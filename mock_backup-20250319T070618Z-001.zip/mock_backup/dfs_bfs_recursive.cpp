/*Represent a given graph using adjacency matrix/list to perform DFS and using 
adjacency list to perform BFS. Use the map of the area around the college as the 
graph. Identify the prominent land marks as nodes and perform DFS and BFS on 
that. */
#include<iostream>
#include<queue>
using namespace std;
vector<vector<int>> createAdjacencyList(int n, int m){
    vector<vector<int>> adj(n+1);
    int u, v;
    //undirected graph
    for(int i = 0; i<m; i++){
        cin>>u;
        cout<<endl;
        cin>>v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    return adj;
}
vector<int> BFS(vector<vector<int>> &adj, int start){
    int n = adj.size();
    vector<int> visited(n, 0);
    queue<int> q;
    vector<int> bfs;
    q.push(start);
    visited[start] = 1;
    while(!q.empty()){
        int toPush = q.front();
        bfs.push_back(toPush);
        q.pop();
        for(auto it : adj[toPush]){
            if(!visited[it]){
                visited[it] = 1;
                q.push(it);
            }
        }
    }
    return bfs;
}
void DFS(int node, vector<int> &ls, vector<vector<int>> &adj, vector<int> &visited){
    visited[node] = 1;
    ls.push_back(node);
    for(auto it : adj[node]){
        if(!visited[it]){
            DFS(it, ls, adj, visited);
        }
    }
}
vector<int> DFStrav(int start, vector<vector<int>> &adj){
    int n = adj.size();
    vector<int> visited(n,0);
    visited[start] = 1;
    vector<int> dfs;
    DFS(start, dfs, adj, visited);
    return dfs;
}
int main(){
    int m, n, start;
   
    cout<<"Enter number of vertices(nodes) : "<<endl;
    cin>>n;
    cout<<"Enter number of edges : "<<endl;
    cin>>m;
    vector<vector<int>> adj(n+1);
    vector<int> bfs(n);
    vector<int> dfs(n);
    adj = createAdjacencyList(n,m);
    cout<<"Enter starting index : "<<endl;
    cin>>start;
   
    for(int i = 0; i<=n; i++){
        cout<<i+1<<" : ";
        for(auto it : adj[i]){
            cout<<it<<"->";
        }
        cout<<endl;
    }
    bfs = BFS(adj, start);
    cout<<"BFS is : "<<endl;
    for(int i = 0; i<n; i++){
        cout<<bfs[i]<<" ";
    }
    cout<<endl;
    cout<<"DFS is : "<<endl;
    dfs = DFStrav(start, adj);
    for(auto it : dfs){
        cout<<it<<" ";
    }
    return 0;
}